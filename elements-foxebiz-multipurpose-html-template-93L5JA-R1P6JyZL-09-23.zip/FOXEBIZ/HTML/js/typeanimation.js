
var typed = new Typed('.typed', {
         strings: ["Today.", "Fast.","Success." ],
         typeSpeed: 80,
         loop: true,
         backSpeed: 40,
         backDelay: 3000
         });